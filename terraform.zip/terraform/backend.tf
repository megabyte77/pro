# # S3 Backend Configuration

# terraform {
#   backend "s3" {
#     bucket         = "my-app-terraform-state"
#     key            = "dev/terraform.tfstate"
#     region         = "us-west-1"
#     encrypt        = true
#     use_lockfile = true
#   }
# }