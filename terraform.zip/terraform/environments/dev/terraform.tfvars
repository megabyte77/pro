aws_region       = "us-west-1"
environment      = "development"
name_prefix      = "webapp"
instance_type    = "t3.medium"
min_instances    = 1
max_instances    = 1
desired_instances = 1
# ami_id will be passed from Packer build