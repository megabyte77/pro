# Get default VPC
data "aws_vpc" "default" {
  default = true
}

# Get all subnets in default VPC
data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

# IAM Module
module "iam" {
  source = "../../modules/iam"

  name_prefix = var.name_prefix
  environment = var.environment
}

# Security Group Module
module "security_group" {
  source = "../../modules/security-group"

  name_prefix = var.name_prefix
  environment = var.environment
  vpc_id      = data.aws_vpc.default.id
}

# ALB Module
module "alb" {
  source = "../../modules/alb"

  name_prefix        = var.name_prefix
  environment        = var.environment
  vpc_id             = data.aws_vpc.default.id
  subnet_ids         = data.aws_subnets.default.ids
  security_group_ids = [module.security_group.alb_security_group_id]
}

# EC2 Module
module "ec2" {
  source = "../../modules/ec2"

  name_prefix           = var.name_prefix
  environment           = var.environment
  ami_id                = var.ami_id
  instance_type         = var.instance_type
  subnet_ids            = data.aws_subnets.default.ids
  security_group_ids    = [module.security_group.ec2_security_group_id]
  instance_profile_name = module.iam.ec2_instance_profile_name
  target_group_arn      = module.alb.target_group_arn
  min_size              = var.min_instances
  max_size              = var.max_instances
  desired_capacity      = var.desired_instances
}