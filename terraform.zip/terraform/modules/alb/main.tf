# Application Load Balancer
resource "aws_lb" "web_app" {
  name               = "${var.name_prefix}-alb-${var.environment}"
  internal           = false
  load_balancer_type = "application"
  security_groups    = var.security_group_ids
  subnets            = var.subnet_ids

  enable_deletion_protection = false

  tags = {
    Name        = "${var.name_prefix}-alb-${var.environment}"
    Environment = var.environment
    Project     = "web-app"
  }
}

# Target Group
resource "aws_lb_target_group" "web_app" {
  name     = "${var.name_prefix}-tg-${var.environment}"
  port     = 8090
  protocol = "HTTP"
  vpc_id   = var.vpc_id

  health_check {
    enabled             = true
    healthy_threshold   = 4
    unhealthy_threshold = 4
    timeout             = 5
    interval            = 30
    path                = "/iqd/index"
    protocol            = "HTTP"
    matcher             = "200"
  }

  tags = {
    Name        = "${var.name_prefix}-tg-${var.environment}"
    Environment = var.environment
    Project     = "web-app"
  }
}

# HTTP Listener
resource "aws_lb_listener" "http_listener" {
  load_balancer_arn = aws_lb.web_app.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.web_app.arn
  }

  tags = {
    Name        = "${var.name_prefix}-http-listener-${var.environment}"
    Environment = var.environment
    Project     = "web-app"
  }
}
