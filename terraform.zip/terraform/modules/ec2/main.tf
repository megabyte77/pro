# Launch Template
resource "aws_launch_template" "web_app" {
  name_prefix = "${var.name_prefix}-web-app-${var.environment}-"
  
  image_id      = var.ami_id
  instance_type = var.instance_type
  key_name      = var.key_name

  iam_instance_profile {
    name = var.instance_profile_name
  }

  network_interfaces {
    associate_public_ip_address = true
    security_groups             = var.security_group_ids
  }

  user_data = base64encode(<<-EOF
    #!/bin/bash
    systemctl start httpd
    systemctl enable httpd
    /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json
  EOF
  )

  tag_specifications {
    resource_type = "instance"

    tags = {
      Name        = "${var.name_prefix}-web-app-${var.environment}"
      Environment = var.environment
      Project     = "web-app"
    }
  }

  tag_specifications {
    resource_type = "volume"

    tags = {
      Name        = "${var.name_prefix}-web-app-${var.environment}"
      Environment = var.environment
      Project     = "web-app"
    }
  }

  lifecycle {
    create_before_destroy = true
  }
}

# Auto Scaling Group
resource "aws_autoscaling_group" "web_app" {
  name_prefix = "${var.name_prefix}-asg-${var.environment}-"
  
  vpc_zone_identifier = var.subnet_ids

  min_size         = var.min_size
  max_size         = var.max_size
  desired_capacity = var.desired_capacity

  launch_template {
    id      = aws_launch_template.web_app.id
    version = "$Latest"
  }

  target_group_arns = [var.target_group_arn]

  health_check_type         = "ELB"
  health_check_grace_period = 300

  tag {
    key                 = "Name"
    value               = "${var.name_prefix}-web-app-${var.environment}"
    propagate_at_launch = true
  }

  tag {
    key                 = "Environment"
    value               = var.environment
    propagate_at_launch = true
  }

  tag {
    key                 = "Project"
    value               = "web-app"
    propagate_at_launch = true
  }

  lifecycle {
    create_before_destroy = true
  }
}