output "launch_template_id" {
  description = "ID of the launch template"
  value       = aws_launch_template.web_app.id
}

output "autoscaling_group_name" {
  description = "Name of the autoscaling group"
  value       = aws_autoscaling_group.web_app.name
}

output "autoscaling_group_arn" {
  description = "ARN of the autoscaling group"
  value       = aws_autoscaling_group.web_app.arn
}