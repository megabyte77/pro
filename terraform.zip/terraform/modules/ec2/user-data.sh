#!/bin/bash
# File: terraform/modules/ec2/user-data.sh

set -e

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a /var/log/user-data.log
}

log "Starting user data script execution..."

# Update hostname
# INSTANCE_ID=$(ec2-metadata --instance-id | cut -d " " -f 2)
# HOSTNAME="${project_name}-${environment}-$INSTANCE_ID"
# sudo hostnamectl set-hostname $HOSTNAME
# log "Hostname set to: $HOSTNAME"

# Start CloudWatch Agent
# log "Starting CloudWatch Agent..."
# sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
#     -a fetch-config \
#     -m ec2 \
#     -s \
#     -c file:/opt/aws/amazon-cloudwatch-agent/etc/cloudwatch-config.json

# Verify CloudWatch Agent is running
# if sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl \
#     -a query -m ec2 -c default -s | grep -q "running"; then
#     log "CloudWatch Agent started successfully"
# else
#     log "ERROR: CloudWatch Agent failed to start"
#     exit 1
# fi

su iqd
# Start tomcat service
log "Starting tomcat service..."
/usr/local/apache-tomcat-9.0.99-PL/bin/startup.sh || log "Failed to start Tomcat" >/dev/null 2>&1

# Verify tomcat is running
if sudo systemctl is-active --quiet tomcat; then
    log "Tomcat started successfully"
else
    log "ERROR: Tomcat failed to start"
    exit 1
fi



# Send custom metric to CloudWatch
# log "Sending startup metric to CloudWatch..."
# aws cloudwatch put-metric-data \
#     --region ${aws_region} \
#     --namespace "CustomApp/EC2" \
#     --metric-name "InstanceStartup" \
#     --value 1 \
#     --dimensions Environment=${environment},Project=${project_name} || log "Failed to send metric"

log "User data script execution completed successfully"