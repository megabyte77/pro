variable "name_prefix" {
  type        = string
  description = "Prefix for resource names"
}

variable "environment" {
  type        = string
  description = "Environment name"
}

variable "ami_id" {
  type        = string
  description = "AMI ID created by Packer"
}

variable "instance_type" {
  type        = string
  description = "EC2 instance type"
  default     = "t3.medium"
}

variable "subnet_ids" {
  type        = list(string)
  description = "List of subnet IDs for EC2 instances"
}

variable "security_group_ids" {
  type        = list(string)
  description = "List of security group IDs for EC2 instances"
}

variable "instance_profile_name" {
  type        = string
  description = "IAM instance profile name"
}

variable "key_name" {
  type        = string
  description = "SSH key pair name"
  default     = null
}

variable "min_size" {
  type        = number
  description = "Minimum number of instances"
  default     = 1
}

variable "max_size" {
  type        = number
  description = "Maximum number of instances"
  default     = 1
}

variable "desired_capacity" {
  type        = number
  description = "Desired number of instances"
  default     = 1
}

variable "target_group_arn" {
  type        = string
  description = "ARN of the target group for the Auto Scaling Group"
}