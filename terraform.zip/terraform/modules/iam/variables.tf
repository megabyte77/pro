variable "name_prefix" {
  type        = string
  description = "Prefix for resource names"
}

variable "environment" {
  type        = string
  description = "Environment name (e.g., production, staging)"
}

variable "cloudwatch_log_groups" {
  type        = list(string)
  description = "List of CloudWatch log groups for permissions"
  default     = ["web-app-access-logs", "web-app-error-logs"]
}