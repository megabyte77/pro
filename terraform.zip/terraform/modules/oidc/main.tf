# OIDC Provider for Azure DevOps
resource "aws_iam_openid_connect_provider" "azure_devops" {
  url = "https://vstoken.visualstudio.com"

  client_id_list = [
    "api://AzureADTokenExchange"
  ]

  thumbprint_list = [
    var.oidc_thumbprint
  ]


  tags = {
    Name        = "${var.name_prefix}-oidc-provider-${var.environment}"
    Environment = var.environment
    Project     = "web-app"
  }
}

# IAM Role for OIDC
resource "aws_iam_role" "oidc_role" {
  name = "${var.name_prefix}-oidc-role-${var.environment}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Federated = aws_iam_openid_connect_provider.azure_devops.arn
        }
        Action = "sts:AssumeRoleWithWebIdentity"
        Condition = {
          StringEquals = {
            "vstoken.visualstudio.com:aud" = "api://AzureADTokenExchange"
          }
          StringLike = {
            "vstoken.visualstudio.com:sub" = "org:${var.azure_devops_organization}:project:${var.azure_devops_project}:*"
          }
        }
      }
    ]
  })

  tags = {
    Name        = "${var.name_prefix}-oidc-role-${var.environment}"
    Environment = var.environment
    Project     = "web-app"
  }
}

# Policy for OIDC role to manage all required services
resource "aws_iam_policy" "oidc_policy" {
  name        = "${var.name_prefix}-oidc-policy-${var.environment}"
  description = "Policy for Azure DevOps OIDC role to manage infrastructure"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ec2:*",
          "elasticloadbalancing:*",
          "autoscaling:*",
          "iam:*",
          "cloudwatch:*",
          "logs:*",
          "s3:*",
          "acm:*",
          "ssm:*"
        ]
        Resource = "*"
      },
      {
        Effect   = "Allow"
        Action   = "sts:AssumeRole"
        Resource = "*"
      }
    ]
  })
}

# Attach policy to OIDC role
resource "aws_iam_role_policy_attachment" "oidc_policy_attachment" {
  role       = aws_iam_role.oidc_role.name
  policy_arn = aws_iam_policy.oidc_policy.arn
}