output "oidc_role_arn" {
  description = "ARN of the OIDC role"
  value       = aws_iam_role.oidc_role.arn
}

output "oidc_provider_arn" {
  description = "ARN of the OIDC provider"
  value       = aws_iam_openid_connect_provider.azure_devops.arn
}