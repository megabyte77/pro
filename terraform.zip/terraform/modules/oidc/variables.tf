variable "name_prefix" {
  type        = string
  description = "Prefix for resource names"
}

variable "environment" {
  type        = string
  description = "Environment name"
}

variable "azure_devops_organization" {
  type        = string
  description = "Azure DevOps organization name"
}

variable "azure_devops_project" {
  type        = string
  description = "Azure DevOps project name"
}

variable "oidc_thumbprint" {
  description = "Thumbprint for Azure DevOps OIDC provider"
  type        = string
  default     = "6938fd4d98bab03faadb97b34396821e3780aea1"
}