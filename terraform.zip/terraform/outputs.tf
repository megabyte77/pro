output "alb_dns_name" {
  description = "DNS name of the Application Load Balancer"
  value       = module.alb.alb_dns_name
}

output "autoscaling_group_name" {
  description = "Name of the autoscaling group"
  value       = module.ec2.autoscaling_group_name
}

output "instance_profile_arn" {
  description = "ARN of the EC2 instance profile"
  value       = module.iam.ec2_instance_profile_arn
}

output "cloudwatch_log_groups" {
  description = "CloudWatch log groups created"
  value       = ["web-app-access-logs", "web-app-error-logs"]
}