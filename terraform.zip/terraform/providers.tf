terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }
}

# Configure the AWS Provider
provider "aws" {
  region  = var.aws_region
  profile = "packer-profile"

  default_tags {
    tags = {
      Environment = var.environment
      Project     = "web-app"
      Terraform   = "true"
    }
  }
}
