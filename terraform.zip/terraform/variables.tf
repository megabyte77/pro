variable "aws_region" {
  type        = string
  description = "AWS region"
  default     = "us-west-1"
}

variable "environment" {
  type        = string
  description = "Environment name"
  default     = "development"
}

variable "name_prefix" {
  type        = string
  description = "Prefix for resource names"
  default     = "webapp"
}

variable "ami_id" {
  type        = string
  description = "AMI ID created by Packer"
}

variable "instance_type" {
  type        = string
  description = "EC2 instance type"
  default     = "t2.micro"
}

variable "min_instances" {
  type        = number
  description = "Minimum number of instances"
  default     = 1
}

variable "max_instances" {
  type        = number
  description = "Maximum number of instances"
  default     = 1
}

variable "desired_instances" {
  type        = number
  description = "Desired number of instances"
  default     = 1
}

# OIDC Configuration
# variable "azure_devops_organization" {
#   type        = string
#   description = "Azure DevOps organization name"
#   default     = null
# }

# variable "azure_devops_project" {
#   type        = string
#   description = "Azure DevOps project name"
#   default     = null
# }
